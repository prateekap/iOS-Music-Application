//
//  Music.swift
//  TestTableView
//
//  Created by Shwetha on 8/15/20.
//  Copyright © 2020 Prateek. All rights reserved.
//

import Foundation

struct Music {
    var title: String
    var cast: [Artist]
    var year: String
    var rating: Int 
}
