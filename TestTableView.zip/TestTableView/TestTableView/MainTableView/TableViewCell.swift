//
//  TableViewCell.swift
//  TestTableView
//
//  Created by Shwetha on 8/15/20.
//  Copyright © 2020 Prateek. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var castLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    
    var viewModel: TableViewCellViewModel? 
    
    override func awakeFromNib() {
        super.awakeFromNib()
        viewModel = TableViewCellViewModel()
    }
    
    func configure(_ music: Music?) {
        guard let music = music  else {
            return 
        }
        titleLabel.text = viewModel?.gettitle(music)
        castLabel.text = viewModel?.getCast(music)
        ratingLabel.text = viewModel?.getRating(music)
    }
}
