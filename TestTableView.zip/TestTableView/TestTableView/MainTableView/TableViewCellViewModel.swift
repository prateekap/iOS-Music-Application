//
//  TableViewCellViewModel.swift
//  TestTableView
//
//  Created by Shwetha on 8/15/20.
//  Copyright © 2020 Prateek. All rights reserved.
//

import Foundation

class TableViewCellViewModel {
    func gettitle(_ music: Music) -> String {
        return "\(music.title)\(music.year))"
    }
    
    func getRating(_ music: Music) -> String {
        return "\(music.rating)%"
    }
    
    func getCast(_ music: Music) -> String {
        var cast: String = ""
        for artist in music.cast {
            cast += "\(artist.name), "
        }
        return cast
    }
}

