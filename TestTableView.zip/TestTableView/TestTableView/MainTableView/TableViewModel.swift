//
//  TableViewModel.swift
//  TestTableView
//
//  Created by Shwetha on 8/15/20.
//  Copyright © 2020 Prateek. All rights reserved.
//

import Foundation

class TableViewModel {
    private var array: [Music]
    
    init() {
        self.array = [Music(title: "Hey Bhagawan",
                            cast: [Artist(name: "Raghu Dixit")],
                            year: "2007",
                            rating: 90),
                      Music(title: "Kaagadada Dhoniyalli",
                            cast: [Artist(name: "Vasuki Vaibhav")],
                            year: "2016",
                            rating: 98),
                      Music(title: "I Wanna Fly",
                            cast: [Artist(name: "Sanjith Hegde")],
                            year: "2018",
                            rating: 96),
                      Music(title: "Good Morning",
                            cast: [Artist(name: "All Ok")],
                            year: "2020",
                            rating: 99)]
    }
    
    func getNumberOfRows() -> Int {
        return array.count
    }
    
    func musicAt(indexPath: IndexPath) -> Music {
       return array[indexPath.row] 
    }
}
